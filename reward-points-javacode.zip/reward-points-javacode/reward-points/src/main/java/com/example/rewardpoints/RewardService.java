package com.example.rewardpoints;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

@Service
public class RewardService {

    public List<Map<String, Object>> calculateRewards() {
        List<Map<String, Object>> rewards = new ArrayList<>();
        Map<Integer, Map<String, Integer>> customerRewards = new HashMap<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader("src/main/java/com/example/rewardpoints/transactions.csv"))) {
            String line;
            br.readLine(); // Skip header row
            
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                int customerId = Integer.parseInt(values[0]);
                double transactionAmount = Double.parseDouble(values[1]);
                LocalDate transactionDate = LocalDate.parse(values[2]);

                int points = calculatePoints(transactionAmount);
                String month = transactionDate.getMonth().name();

                customerRewards.computeIfAbsent(customerId, k -> new HashMap<>()).merge(month, points, Integer::sum);
            }
            
            for (Map.Entry<Integer, Map<String, Integer>> entry : customerRewards.entrySet()) {
                Map<String, Object> reward = new HashMap<>();
                reward.put("customerId", entry.getKey());
                reward.put("monthlyRewards", entry.getValue());
                reward.put("totalRewards", entry.getValue().values().stream().mapToInt(Integer::intValue).sum());
                rewards.add(reward);
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return rewards;
    }

    private int calculatePoints(double amount) {
        if (amount <= 50) return 0;
        if (amount <= 100) return (int) (amount - 50);
        return 50 + 2 * (int) (amount - 100);
    }
}
