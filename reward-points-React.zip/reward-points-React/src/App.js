import React from 'react';
import './App.css';
import RewardsTable from './RewardsTable'; // Ensure this path is correct

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Customer Rewards</h1>
      </header>
      <main>
        <RewardsTable /> {/* Embedding the RewardsTable component */}
      </main>
    </div>
  );
}

export default App;
