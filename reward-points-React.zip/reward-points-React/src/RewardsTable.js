import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './RewardsTable.css'; // Assuming you have created a CSS file for styling

function RewardsTable() {
  const [rewards, setRewards] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/api/rewards')
      .then(response => {
        setRewards(response.data);
        setError(null);
      })
      .catch(error => {
        console.error('There was an error fetching the rewards!', error);
        setError('There was an error fetching the rewards!');
      });
  }, []);

  return (
    <div className="rewards-container">
      {error && <p className="error-message">{error}</p>}
      <table className="rewards-table">
        <thead>
          <tr>
            <th>Customer ID</th>
            {rewards.length > 0 && Object.keys(rewards[0].monthlyRewards).map(month => (
              <th key={month}>{month}</th>
            ))}
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {rewards.map(reward => (
            <tr key={reward.customerId}>
              <td>{reward.customerId}</td>
              {Object.values(reward.monthlyRewards).map((points, index) => (
                <td key={index}>{points}</td>
              ))}
              <td>{reward.totalRewards}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default RewardsTable;
